import UIKit

//============================>>
//====== MONSTER ======>>
protocol Monster {
    var name: String { get }
    
    func roar() -> String
} // Monster

//=================================>>
//== FLYING MONSTER: MONSTER ==>>
protocol FlyingMonster: Monster {
    var wingSpan: Double { get }
    
    func fly() -> String
} // FlyingMonster

//=================================>>
//== WATER MONSTER: MONSTER ==>>
protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    
    func swim() -> String
} // WaterMonster

//=================================>>
//== DRAGON: FLYING MONSTER ==>>
class Dragon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    
    func roar() -> String {
        return "\(self.name) roars fiercely, shaking the ground!"
    }

    func fly() -> String {
        return "\(self.name) spreads its \(self.wingSpan)-meter wings and takes to the sky!"
    }

} // Dragon

//=================================>>
//== GRYPHON: FLYING MONSTER ==>>
class Gryphon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    
    func roar() -> String {
        return "\(self.name) screeches with a piercing cry!"
    }

    func fly() -> String {
        return "\(self.name) soars high with its majestic \(self.wingSpan)-meter wings!"
    }

} // Gryphon

//=================================>>
//== KRAKEN: WATER MONSTER ==>>
class Kraken: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }
    
    func roar() -> String {
        return "\(self.name) bellows from the deep, causing waves to crash!"
    }
 
    func swim() -> String {
        return "\(self.name) glides through the water at \(self.swimSpeed) knots!"
    }

} // Kraken

//=================================>>
//== MERFOLK: FLYING MONSTER ==>>
class MerFolk: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }
    
    func roar() -> String {
        return "\(self.name) sings an enchanting melody that stirs the seas!"
    }
 
    func swim() -> String {
        return "\(self.name) swims gracefully at \(self.swimSpeed) knots!"
    }

} // Merfolk

func printMonsterDetails(monsters: [Monster]) {
    for m in monsters {
        print("\(m.roar())")
        if let flyingMonster = m as? FlyingMonster {
            print("\(flyingMonster.fly())")
            print("--------------------------------------")
        } else if let waterMonster = m as? WaterMonster {
            print("\(waterMonster.swim())")
            print("--------------------------------------")
        }
    }
} // printMonsterDetails()

// Class instances
let dragon: Dragon = Dragon(name: "Fire Drake", wingSpan: 15.0)
let gryphon: Gryphon = Gryphon(name: "Sky Hunter", wingSpan: 12.0)
let kraken: Kraken = Kraken(name: "Sea Terror", swimSpeed: 20)
let merfolk: MerFolk = MerFolk(name: "Coral Queen", swimSpeed: 10)

// Monster Array
let allMonsters: [Monster] = [dragon, gryphon, kraken, merfolk]

// Function call
printMonsterDetails(monsters: allMonsters)


